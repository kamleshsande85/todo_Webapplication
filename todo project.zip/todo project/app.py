from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///todo.db'
db = SQLAlchemy(app)


class Products(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    desc = db.Column(db.Integer, nullable=False)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"{self.id} - {self.title}"

@app.route('/')
def home():
    return redirect("products")


@app.route('/products',methods=['GET','POST'])
def myname():
    if request.method == 'POST':
        title = request.form['title']
        desc = request.form['desc']
        todo = Products(title=title, desc=desc)
        db.session.add(todo)
        db.session.commit()

    todoall = Products.query.all()
    return render_template('index.html',todoall=todoall)


@app.route('//Delete/<int:id>')
def delete(id):
    
    todo = Products.query.filter_by(id=id).first()
  
    if todo:
        db.session.delete(todo)
        db.session.commit()
    
    return redirect('/products')

@app.route('/Update/<int:id>', methods=['GET', 'POST'])
def update(id):
    todo = Products.query.filter_by(id=id).first()
    
    
    if request.method == 'POST':
        title = request.form['title']
        desc = request.form['desc']
        
        if todo:
            todo.title = title
            todo.desc = desc
            db.session.commit()
            return redirect('/products')
    
    return render_template('update.html', todo=todo)




if __name__ == '__main__':
    app.run(debug=True,port=8100) 